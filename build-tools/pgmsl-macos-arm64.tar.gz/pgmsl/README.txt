pgmsl: offline shader translator of the GTA V iOS port (https://github.com/kevinerikjs/gta5-ios-port).
Source: pgmsl.cc (MIT, this project), linked statically against Google's Tint from Dawn
(BSD-3-Clause, see LICENSE-dawn-tint) and Abseil (Apache-2.0, see LICENSE-abseil).
macOS 13+, Apple Silicon. Contains no game files.
